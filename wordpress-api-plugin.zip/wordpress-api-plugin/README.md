# Wordpress API widget #

## Overview ##
The Wordpress widget is a single file. The .zip file can be directly installed in Wordpress. The short-command to call the function, and list the articles, is [articles-api].

## Live Version ##
The widget has been tested, and a published version can be found on: http://ralphblackferguson.com/programs/wordpress/wordpress-api/

## Challenges ##
As far as I have understood, a widget in Wordpress has a relatively large number of files — for security and other reasons. I tried to create a widget using the boilerplate generated on https://wppb.me/, but there seemed to be a lot of code that needed to be filled in. And I made the decision to limit to scope of this project to not include the excess files.
